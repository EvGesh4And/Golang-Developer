//go:build !race

package main
